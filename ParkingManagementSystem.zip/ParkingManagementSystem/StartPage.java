import javax.swing.*;

import java.awt.*;

import java.awt.event.ComponentAdapter;

import java.awt.event.ComponentEvent;
 
public class StartPage {
 
    public static JPanel createStartPage() {

        // Create a layered pane to overlay the button on the image

        JLayeredPane layeredPane = new JLayeredPane();
 
        // Correct path to the new .jpg image

        String imagePath = "C:/Users/Lenovo/Downloads/1stpg.jpeg";  // Or use "C:\Users\Lenovo\Downloads\\1stpg.jpeg"

        // Load the image using ImageIcon

        ImageIcon icon = new ImageIcon(imagePath);

        JLabel imageLabel = new JLabel(icon);
 
        // Set the size and position of the imageLabel in the layered pane

        imageLabel.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());

        // Add the image to the layered pane at the default layer

        layeredPane.add(imageLabel, JLayeredPane.DEFAULT_LAYER);
 
        // Create the "Get Started" button

        JButton getStartedButton = new JButton("Get Started");

        getStartedButton.setFont(new Font("Arial", Font.BOLD, 36));  // Large font size

        getStartedButton.setFocusPainted(false);

        getStartedButton.setBackground(new Color(0, 100, 0));  // Dark green background

        getStartedButton.setForeground(Color.WHITE);  // White text

        getStartedButton.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));  // Padding around button
 
        // Add action listener to navigate to the login panel

        getStartedButton.addActionListener(e -> CarParkingApp.showLoginPanel());
 
        // Create a panel to hold the button (center it)

        JPanel buttonPanel = new JPanel(new GridBagLayout());

        buttonPanel.setOpaque(false);  // Make the button panel transparent so the image shows through

        buttonPanel.add(getStartedButton);
 
        // Set the size and position of the button panel in the layered pane

        buttonPanel.setBounds(0, icon.getIconHeight() - 100, icon.getIconWidth(), 100);  // Adjust position as needed
 
        // Add the button panel on top of the image

        layeredPane.add(buttonPanel, JLayeredPane.PALETTE_LAYER);  // Add the button to a higher layer
 
        // Add a listener to resize the components when the window size changes

        layeredPane.addComponentListener(new ComponentAdapter() {

            @Override

            public void componentResized(ComponentEvent e) {

                // Resize the image and button panel based on the new panel size

                int panelWidth = layeredPane.getWidth();

                int panelHeight = layeredPane.getHeight();
 
                // Scale the image to fit the panel

                Image scaledImage = icon.getImage().getScaledInstance(panelWidth, panelHeight, Image.SCALE_SMOOTH);

                imageLabel.setIcon(new ImageIcon(scaledImage));

                imageLabel.setBounds(0, 0, panelWidth, panelHeight);
 
                // Position the button panel in the center-bottom of the image

                buttonPanel.setBounds(0, panelHeight - 150, panelWidth, 100);  // Adjust the Y-offset for the button position

            }

        });
 
        // Create the main panel and add the layeredPane

        JPanel mainPanel = new JPanel(new BorderLayout());

        mainPanel.add(layeredPane, BorderLayout.CENTER);
 
        return mainPanel;

    }

}

 