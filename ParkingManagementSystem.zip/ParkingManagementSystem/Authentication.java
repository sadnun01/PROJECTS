import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Authentication {

    private static final Map<String, String> users = new HashMap<>();
    private static String currentUser;
    private static final Color DARK_GREEN = new Color(0, 100, 0);
    private static final Color DARK_GREY = new Color(30, 30, 30); // Dark grey color
    private static final String IMAGE_PATH = "C:\\Users\\Lenovo\\Downloads\\2ndpg.jpeg"; // Path to the background image

    public static JPanel createLoginPanel() {
        JPanel panel = createImageBackgroundPanel();
        GridBagConstraints gbc = createGbc();

        JLabel userLabel = new JLabel("Username:");
        userLabel.setForeground(Color.BLACK);
        JTextField userText = new JTextField(15);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setForeground(Color.BLACK);
        JPasswordField passText = new JPasswordField(15);

        JButton loginButton = new JButton("Login");
        JButton signupButton = new JButton("Sign Up");
        JButton forgotPassButton = new JButton("Forgot Password");

        setButtonStyle(loginButton);
        setButtonStyle(signupButton);
        setButtonStyle(forgotPassButton);

        loginButton.addActionListener(e -> loginUser(userText, passText));
        signupButton.addActionListener(e -> CarParkingApp.showSignupPanel());
        forgotPassButton.addActionListener(e -> CarParkingApp.showForgotPasswordPanel());

        addComponentsToPanel(panel, gbc, userLabel, userText, passLabel, passText, loginButton, signupButton, forgotPassButton);

        return panel;
    }

    public static JPanel createSignupPanel() {
        JPanel panel = createImageBackgroundPanel();
        GridBagConstraints gbc = createGbc();

        JLabel userLabel = new JLabel("Username:");
        userLabel.setForeground(Color.BLACK);
        JTextField userText = new JTextField(15);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setForeground(Color.BLACK);
        JPasswordField passText = new JPasswordField(15);

        JLabel confirmPassLabel = new JLabel("Confirm Password:");
        confirmPassLabel.setForeground(Color.BLACK);
        JPasswordField confirmPassText = new JPasswordField(15);

        JButton registerButton = new JButton("Register");
        JButton backButton = new JButton("Back");

        setButtonStyle(registerButton);
        setButtonStyle(backButton);

        registerButton.addActionListener(e -> registerUser(userText, passText, confirmPassText));
        backButton.addActionListener(e -> CarParkingApp.showLoginPanel());

        addComponentsToPanel(panel, gbc, userLabel, userText, passLabel, passText, confirmPassLabel, confirmPassText, registerButton, backButton);

        return panel;
    }

    public static JPanel createForgotPasswordPanel() {
        JPanel panel = createImageBackgroundPanel();
        GridBagConstraints gbc = createGbc();

        JLabel userLabel = new JLabel("Username:");
        userLabel.setForeground(Color.BLACK);
        JTextField userText = new JTextField(15);

        JLabel newPassLabel = new JLabel("New Password:");
        newPassLabel.setForeground(Color.BLACK);
        JPasswordField newPassText = new JPasswordField(15);

        JButton resetPassButton = new JButton("Reset Password");
        JButton backButton = new JButton("Back");

        setButtonStyle(resetPassButton);
        setButtonStyle(backButton);

        resetPassButton.addActionListener(e -> resetPassword(userText, newPassText));
        backButton.addActionListener(e -> CarParkingApp.showLoginPanel());

        addComponentsToPanel(panel, gbc, userLabel, userText, newPassLabel, newPassText, resetPassButton, backButton);

        return panel;
    }

    // Method to create a panel with a background image
    private static JPanel createImageBackgroundPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    Image bgImage = ImageIO.read(new File(IMAGE_PATH)); // Load the image
                    g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this); // Scale the image to fit the panel
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        panel.setLayout(new GridBagLayout());
        return panel;
    }

    private static void setButtonStyle(JButton button) {
        button.setBackground(DARK_GREEN);
        button.setForeground(Color.WHITE);
    }

    private static void loginUser(JTextField userText, JPasswordField passText) {
        String username = userText.getText();
        String password = new String(passText.getPassword());

        if (users.containsKey(username) && Objects.equals(users.get(username), password)) {
            setCurrentUser(username);
            JOptionPane.showMessageDialog(null, "Welcome, " + username + "!");
            CarParkingApp.showMainMenuPanel();
        } else {
            JOptionPane.showMessageDialog(null, "Invalid username or password");
        }
    }

    private static void registerUser(JTextField userText, JPasswordField passText, JPasswordField confirmPassText) {
        String username = userText.getText();
        String password = new String(passText.getPassword());
        String confirmPassword = new String(confirmPassText.getPassword());

        if (password.equals(confirmPassword)) {
            if (!users.containsKey(username)) {
                users.put(username, password);
                saveUserInfoToFile(username, password); // Save to file
                JOptionPane.showMessageDialog(null, "Registration successful");
                CarParkingApp.showLoginPanel();
            } else {
                JOptionPane.showMessageDialog(null, "Username already exists");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Passwords do not match");
        }
    }

    private static void saveUserInfoToFile(String username, String password) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("userinfo.txt", true))) {
            writer.write("Username: " + username + ", Password: " + password);
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving user information.");
        }
    }

    private static void resetPassword(JTextField userText, JPasswordField newPassText) {
        String username = userText.getText();
        String newPassword = new String(newPassText.getPassword());

        if (users.containsKey(username)) {
            users.put(username, newPassword);
            JOptionPane.showMessageDialog(null, "Password reset successfully");
            CarParkingApp.showLoginPanel();
        } else {
            JOptionPane.showMessageDialog(null, "Username does not exist");
        }
    }

    public static void setCurrentUser(String username) {
        currentUser = username;
    }

    public static String getCurrentUser() {
        return currentUser;
    }

    private static GridBagConstraints createGbc() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        return gbc;
    }

    private static void addComponentsToPanel(JPanel panel, GridBagConstraints gbc, Component... components) {
        int gridY = 0;
        for (Component component : components) {
            gbc.gridy = gridY++;
            panel.add(component, gbc);
        }
    }
}
