import javax.swing.*;
import java.awt.*;

public class ParkingActions {

    private static double totalCost;
    private static int hoursParked;

    // Create the main menu panel
    public static JPanel createMainMenuPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = createGbc();

        JButton parkCarButton = createStyledButton("Park Car");
        JButton logoutButton = createStyledButton("Logout");

        // Action for parking a car
        parkCarButton.addActionListener(e -> CarParkingApp.showParkCarPanel());

        // Action for logout button
        logoutButton.addActionListener(e -> {
            Authentication.setCurrentUser(null); // Clear current user
            CarParkingApp.showLoginPanel(); // Redirect to login
        });

        // Layout components
        gbc.gridy = 1;
        panel.add(parkCarButton, gbc);
        gbc.gridy = 2;
        panel.add(logoutButton, gbc);

        return panel;
    }

    // Create the panel for parking a car
    public static JPanel createParkCarPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = createGbc();

        JLabel carModelLabel = new JLabel("Car Model:");
        JComboBox<String> carModelBox = new JComboBox<>(new String[]{"Select Model", "Toyota", "Audi", "Ford", "Lexus", "Honda", "BMW"});
        JButton nextButton = createStyledButton("Next");
        JButton backButton = createStyledButton("Back");

        // Action for the next button
        nextButton.addActionListener(e -> {
            if (carModelBox.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(null, "Please select a car model.");
            } else {
                CarParkingApp.showLocationSelectionPanel();
            }
        });

        // Action for back button
        backButton.addActionListener(e -> CarParkingApp.showMainMenuPanel());

        // Layout components
        gbc.gridy = 0;
        panel.add(carModelLabel, gbc);
        gbc.gridx = 1;
        panel.add(carModelBox, gbc);
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panel.add(nextButton, gbc);
        gbc.gridy = 2;
        panel.add(backButton, gbc);

        return panel;
    }

    // Create the location selection panel
    public static JPanel createLocationSelectionPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = createGbc();

        JLabel locationLabel = new JLabel("Select Location:");
        JComboBox<String> locationBox = new JComboBox<>(new String[]{"Location A", "Location B", "Location C"});
        JButton proceedButton = createStyledButton("Proceed to Booking");
        JButton backButton = createStyledButton("Back");

        // Action for the proceed button
        proceedButton.addActionListener(e -> {
            if (locationBox.getSelectedIndex() == -1) {
                JOptionPane.showMessageDialog(null, "Please select a location.");
            } else {
                CarParkingApp.showBookParkingPanel();
            }
        });

        // Action for back button
        backButton.addActionListener(e -> CarParkingApp.showParkCarPanel());

        // Layout components
        gbc.gridy = 0;
        panel.add(locationLabel, gbc);
        gbc.gridx = 1;
        panel.add(locationBox, gbc);
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panel.add(proceedButton, gbc);
        gbc.gridy = 2;
        panel.add(backButton, gbc);

        return panel;
    }

    // Create the booking panel
    public static JPanel createBookParkingPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = createGbc();

        JLabel hoursLabel = new JLabel("Number of Hours:");
        JTextField hoursField = new JTextField(10);
        JLabel rateLabel = new JLabel("Rate per Hour ($):");
        JTextField rateField = new JTextField(10);
        JButton calculateButton = createStyledButton("Calculate Cost");
        JLabel totalLabel = new JLabel("Total Cost: $0");
        JTextField couponField = new JTextField(10);
        JButton applyCouponButton = createStyledButton("Apply Coupon");
        JButton removeCouponButton = createStyledButton("Remove Coupon");
        JLabel finalCostLabel = new JLabel("Final Cost: $0");
        JButton proceedButton = createStyledButton("Proceed to Payment");
        JButton backButton = createStyledButton("Back");

        // Calculate total cost action
        calculateButton.addActionListener(e -> calculateTotalCost(hoursField, rateField, totalLabel, finalCostLabel));

        // Apply coupon action
        applyCouponButton.addActionListener(e -> applyCoupon(couponField, totalLabel, finalCostLabel));

        // Remove coupon action
        removeCouponButton.addActionListener(e -> {
            finalCostLabel.setText("Final Cost: $0");
            couponField.setText(""); // Clear the coupon field
            JOptionPane.showMessageDialog(null, "Coupon removed.");
        });

        // Proceed to payment action
        proceedButton.addActionListener(e -> {
            if (finalCostLabel.getText().equals("Final Cost: $0")) {
                JOptionPane.showMessageDialog(null, "Please calculate cost before proceeding to payment.");
            } else {
                CarParkingApp.showPaymentPanel();
            }
        });

        // Action for back button
        backButton.addActionListener(e -> CarParkingApp.showLocationSelectionPanel());

        // Layout components
        gbc.gridy = 0;
        gbc.gridx = 0;
        panel.add(hoursLabel, gbc);
        gbc.gridx = 1;
        panel.add(hoursField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(rateLabel, gbc);
        gbc.gridx = 1;
        panel.add(rateField, gbc);
        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        panel.add(calculateButton, gbc);
        gbc.gridy = 3;
        panel.add(totalLabel, gbc);
        gbc.gridy = 4;
        panel.add(new JLabel("Coupon Code :"), gbc);
        gbc.gridy = 5;
        panel.add(couponField, gbc);

        // Adding the Apply and Remove buttons
        gbc.gridy = 6;
        gbc.gridx = 0;
        panel.add(applyCouponButton, gbc);
        gbc.gridy = 7; // Move Remove Coupon to the next row
        panel.add(removeCouponButton, gbc);
        gbc.gridx = 0; // Reset to original position
        gbc.gridy = 8; // Move Final Cost to the next row
        panel.add(finalCostLabel, gbc);
        gbc.gridy = 9;
        panel.add(proceedButton, gbc);
        gbc.gridy = 10; // Move Back button to the next row
        panel.add(backButton, gbc);

        return panel;
    }

    // Create the payment panel
    public static JPanel createPaymentPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = createGbc();

        JLabel paymentLabel = new JLabel("Select Payment Method:");
        JButton bkashButton = createStyledButton("Bkash");
        JButton cardButton = createStyledButton("Credit/Debit Card");
        JButton cashButton = createStyledButton("Cash");
        JButton backButton = createStyledButton("Back");

        // Bkash payment action
        bkashButton.addActionListener(e -> processBkashPayment(panel));

        // Card payment action
        cardButton.addActionListener(e -> processCardPayment(panel));

        // Cash payment action
        cashButton.addActionListener(e -> {
            showPaymentDue(); // Show due for cash payment
            showInvoice();
        });

        // Action for back button
        backButton.addActionListener(e -> CarParkingApp.showBookParkingPanel());

        // Layout components
        gbc.gridy = 0;
        panel.add(paymentLabel, gbc);
        gbc.gridy = 1;
        panel.add(bkashButton, gbc);
        gbc.gridy = 2;
        panel.add(cardButton, gbc);
        gbc.gridy = 3;
        panel.add(cashButton, gbc);
        gbc.gridy = 4;
        panel.add(backButton, gbc);

        return panel;
    }

    // Show payment success message
    public static void showPaymentSuccess() {
        JOptionPane.showMessageDialog(null, "Payment Successful! Thank you for choosing ParkingChai.");
        CarParkingApp.showMainMenuPanel(); // Return to main menu
    }

    // Show payment due message
    public static void showPaymentDue() {
        JOptionPane.showMessageDialog(null, "Payment Due! Please pay at the counter.");
    }

    // Show invoice details
    private static void showInvoice() {
        String invoiceDetails = "Invoice:\n" +
                "User: " + Authentication.getCurrentUser() + "\n" +
                "Hours Parked: " + hoursParked + "\n" +
                "Total Cost: $" + totalCost + "\n" +
                "Thank you for using ParkingChai!";
        JOptionPane.showMessageDialog(null, invoiceDetails, "Invoice", JOptionPane.INFORMATION_MESSAGE);
    }

    // Create GridBagConstraints for layout
    private static GridBagConstraints createGbc() {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Adds space around components
        gbc.anchor = GridBagConstraints.CENTER; // Align components to the center
        gbc.fill = GridBagConstraints.HORIZONTAL; // Allow components to stretch horizontally
        return gbc;
    }

    // Create styled buttons
    private static JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(0, 100, 0)); // Dark green
        button.setForeground(Color.WHITE); // White text
        return button;
    }

    // Validate phone number format
    private static boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber != null && phoneNumber.matches("\\d+"); // Allow any length of digits
    }

    // Validate card number format
    private static boolean isValidCardNumber(String cardNumber) {
        return cardNumber != null && cardNumber.matches("\\d+"); // Allow any length of digits
    }

    // Validate PIN format
    private static boolean isValidPin(String pin) {
        return pin != null && pin.matches("\\d{4}"); // Example: 4-digit PIN
    }

    // Calculate total cost
    private static void calculateTotalCost(JTextField hoursField, JTextField rateField, JLabel totalLabel, JLabel finalCostLabel) {
        try {
            hoursParked = Integer.parseInt(hoursField.getText());
            double rate = Double.parseDouble(rateField.getText());

            if (hoursParked < 1 || rate < 0) {
                JOptionPane.showMessageDialog(null, "Please enter valid values.");
                return;
            }

            totalCost = hoursParked * rate;
            totalLabel.setText("Total Cost: $" + totalCost);
            finalCostLabel.setText("Final Cost: $" + totalCost); // Reset final cost

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Please enter valid numbers.");
        }
    }

    // Apply coupon
    private static void applyCoupon(JTextField couponField, JLabel totalLabel, JLabel finalCostLabel) {
        if (couponField.getText().equals("10%")) {
            try {
                double discount = totalCost * 0.10; // 10% discount
                double finalCost = totalCost - discount;
                finalCostLabel.setText("Final Cost: $" + finalCost);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please calculate total cost first.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Invalid coupon code. Please use '10%' for a discount.");
        }
    }

    // Process Bkash payment
    private static void processBkashPayment(JPanel panel) {
        String phoneNumber = JOptionPane.showInputDialog(panel, "Enter Bkash Phone Number for " + Authentication.getCurrentUser() + ":");
        if (isValidPhoneNumber(phoneNumber)) {
            String pin = JOptionPane.showInputDialog(panel, "Enter Bkash PIN for " + Authentication.getCurrentUser() + ":");
            if (isValidPin(pin)) {
                String otp = JOptionPane.showInputDialog(panel, "Enter OTP for " + Authentication.getCurrentUser() + ":");
                if (!otp.isEmpty()) {
                    showPaymentSuccess();
                    showInvoice();
                } else {
                    JOptionPane.showMessageDialog(panel, "Please enter a valid OTP.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(panel, "Please enter a valid PIN.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(panel, "Please enter a valid phone number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Process card payment
    private static void processCardPayment(JPanel panel) {
        String cardNumber = JOptionPane.showInputDialog(panel, "Enter Card Number for " + Authentication.getCurrentUser() + ":");
        if (isValidCardNumber(cardNumber)) {
            String pin = JOptionPane.showInputDialog(panel, "Enter Card PIN for " + Authentication.getCurrentUser() + ":");
            if (isValidPin(pin)) {
                String otp = JOptionPane.showInputDialog(panel, "Enter OTP for " + Authentication.getCurrentUser() + ":");
                if (!otp.isEmpty()) {
                    showPaymentSuccess();
                    showInvoice();
                } else {
                    JOptionPane.showMessageDialog(panel, "Please enter a valid OTP.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(panel, "Please enter a valid PIN.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(panel, "Please enter a valid card number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}