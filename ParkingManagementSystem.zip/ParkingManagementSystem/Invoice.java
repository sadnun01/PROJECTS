import javax.swing.*;
import java.awt.*;

public class Invoice {

    // Display invoice details
    public static void showInvoice(String userName, int hoursParked, double totalCost, double discountAmount) {
        String invoiceDetails = "Invoice:\n" +
                "User: " + userName + "\n" +
                "Hours Parked: " + hoursParked + "\n" +
                "Total Cost: $" + totalCost + "\n" +
                "Discount Applied: $" + discountAmount + "\n" +
                "Final Cost: $" + (totalCost - discountAmount) + "\n" +
                "Thank you for using ParkingChai!";

        // Create a panel to show the invoice and include a "Park Again" button
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridy = 0;

        // Add the invoice details
        JTextArea invoiceArea = new JTextArea(invoiceDetails);
        invoiceArea.setEditable(false);
        panel.add(invoiceArea, gbc);

        // Add a "Park Again" button
        JButton parkAgainButton = new JButton("Park Again");
        parkAgainButton.addActionListener(e -> CarParkingApp.showParkCarPanel());

        gbc.gridy = 1;
        panel.add(parkAgainButton, gbc);

        // Show the invoice panel in a dialog
        JOptionPane.showMessageDialog(null, panel, "Invoice", JOptionPane.INFORMATION_MESSAGE);
    }
}
