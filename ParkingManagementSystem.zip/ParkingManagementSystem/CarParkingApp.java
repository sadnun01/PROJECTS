import javax.swing.*;

import java.awt.*;
 
public class CarParkingApp {

    private static JFrame mainFrame;
 
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            initializeMainFrame();

            addPanelsToFrame();

            showStartPage();

            mainFrame.setVisible(true);

        });

    }
 
    private static void initializeMainFrame() {

        mainFrame = new JFrame("Car Parking App");

        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mainFrame.setSize(600, 500);

        mainFrame.setLayout(new CardLayout());

    }
 
    private static void addPanelsToFrame() {

        mainFrame.add(StartPage.createStartPage(), "StartPage");

        mainFrame.add(Authentication.createLoginPanel(), "Login");

        mainFrame.add(Authentication.createSignupPanel(), "Signup");

        mainFrame.add(Authentication.createForgotPasswordPanel(), "ForgotPassword");

        mainFrame.add(ParkingActions.createMainMenuPanel(), "MainMenu");

        mainFrame.add(ParkingActions.createParkCarPanel(), "ParkCar");

        mainFrame.add(ParkingActions.createBookParkingPanel(), "BookParking");

        mainFrame.add(ParkingActions.createLocationSelectionPanel(), "LocationSelection");

        mainFrame.add(ParkingActions.createPaymentPanel(), "Payment");

    }
 
    private static void showStartPage() {

        showPanel("StartPage");

    }
 
    private static void showPanel(String panelName) {

        CardLayout cardLayout = (CardLayout) (mainFrame.getContentPane().getLayout());

        cardLayout.show(mainFrame.getContentPane(), panelName);

    }
 
    public static void showLoginPanel() {

        showPanel("Login");

    }
 
    public static void showSignupPanel() {

        showPanel("Signup");

    }
 
    public static void showForgotPasswordPanel() {

        showPanel("ForgotPassword");

    }
 
    public static void showMainMenuPanel() {

        showPanel("MainMenu");

    }
 
    public static void showParkCarPanel() {

        showPanel("ParkCar");

    }
 
    public static void showBookParkingPanel() {

        showPanel("BookParking");

    }
 
    public static void showLocationSelectionPanel() {

        showPanel("LocationSelection");

    }
 
    public static void showPaymentPanel() {

        showPanel("Payment");

    }

}

 